create view table_rooms as
select `r`.`ID_room`              AS `ID_room`,
       `r`.`name`                 AS `roomName`,
       `r`.`fullName`             AS `roomFullName`,
       `r`.`seats`                AS `seats`,
       `r`.`floor`                AS `floor`,
       `r`.`wing`                 AS `wing`,
       `r`.`max_time_reservation` AS `max_time_reservation`,
       `r`.`reservation_ability`  AS `reservation_ability`,
       `b`.`ID_building`          AS `ID_building`,
       `b`.`name`                 AS `buildingName`,
       `b`.`fullName`             AS `buildingFullName`,
       `b`.`town`                 AS `town`,
       `b`.`address`              AS `address`,
       `b`.`area`                 AS `area`,
       `t`.`id_type`              AS `id_type`,
       `t`.`name`                 AS `typeName`
from ((`srs`.`rooms` `r` join `srs`.`buildings` `b` on ((`b`.`ID_building` = `r`.`ID_building`)))
         join `srs`.`room_types` `t` on ((`r`.`id_type` = `t`.`id_type`)));

